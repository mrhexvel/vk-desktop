import {
  ExecuteProfiles,
  VKConversationItem,
  VKGetConversationsResponse,
  VKGroup,
  VKMessageHistory,
  VKProfile,
} from "@/types/vk.type";

export class VKApiService {
  private readonly accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
  }

  async getConversations(): Promise<VKGetConversationsResponse["response"]> {
    try {
      const response = await window.vkApi.getConversations(this.accessToken);
      return response;
    } catch (error) {
      console.error("Error fetching conversations:", error);
      throw error;
    }
  }

  async execute(code: string): Promise<ExecuteProfiles> {
    try {
      const response = await window.vkApi.execute(this.accessToken, code);
      return response;
    } catch (error) {
      console.error("Error execute:", error);
      throw error;
    }
  }

  async usersGet(user_ids?: string): Promise<VKProfile[]> {
    try {
      const response = await window.vkApi.usersGet(this.accessToken, user_ids);
      return response;
    } catch (error) {
      console.error("Error execute:", error);
      throw error;
    }
  }

  async groupsGetById(group_id: number): Promise<VKGroup> {
    try {
      const response = await window.vkApi.groupsGetById(
        this.accessToken,
        group_id
      );
      return response;
    } catch (error) {
      console.error("Error execute:", error);
      throw error;
    }
  }

  async getHistory(peer_id: number): Promise<VKMessageHistory> {
    try {
      const response = await window.vkApi.getHistory(this.accessToken, peer_id);
      return response;
    } catch (error) {
      console.error("Error execute:", error);
      throw error;
    }
  }

  static getConversationAvatar(
    conversation: VKConversationItem,
    profiles: VKProfile[],
    groups: VKGroup[]
  ): string | undefined {
    const { peer } = conversation.conversation;
    if (peer.type === "user") {
      const profile = profiles.find((p) => p.id === peer.id);
      return profile?.photo_100;
    } else if (peer.type === "chat") {
      return conversation.conversation.chat_settings?.photo?.photo_100;
    } else if (peer.type === "group") {
      const group = groups.find((g) => g.id === -peer.id);
      return group?.photo_100;
    }
    return undefined;
  }
}

declare global {
  interface Window {
    vkApi: {
      getConversations: (
        accessToken: string
      ) => Promise<VKGetConversationsResponse["response"]>;

      execute: (accessToken: string, code: string) => Promise<ExecuteProfiles>;

      usersGet: (
        accessToken: string,
        user_ids?: string
      ) => Promise<VKProfile[]>;

      groupsGetById: (
        accessToken: string,
        group_id: number
      ) => Promise<VKGroup>;

      getHistory: (
        accessToken: string,
        peer_id: number
      ) => Promise<VKMessageHistory>;
    };
  }
}

// да, я долбаёб, но об этом никому 🤫
export const vkService = new VKApiService(
  "vk1.a.mfQzMAuwTzGElzxWQJUekFistD4C4vF0AKnCK7w1lsYcxdAiK0lN5Ljp5C-E0EKwKTiXDX38gEctcEQ-cxEvG-pQ-4OxOnqGa01rG2EQYdLAZhFvOm7uAtKRxyZfV518QL6bxg8fjG7NSLz_ni1b9lYI-A5NvUr0q_-bI5enRwh3wre-saF9zi2RGdhgzXKCD0pgSHUf0XgyyczVp5TQIA"
);
